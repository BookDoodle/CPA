# Club Penguin Homepage Archive!

## How to add your logo to the Website.
If you want to make a CPPS Homepage with this its very simple. The "Club Penguin" Logo is in /img/common/logo-large.png

## How to edit the Website.
Everything else for the adding links and such to the homepage will be in index.html and /scripts/footer.php
the "disney virtual worlds" logo is in /img/common/logo-disney-virtual-world.png